package com.example.applegameauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent

class AppleAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AppleAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    fun drag(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        duration: Long = 180L
    ): Boolean {

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            return false
        }

        val path = Path()
        path.moveTo(startX, startY)
        path.lineTo(endX, endY)

        val stroke =
            GestureDescription.StrokeDescription(
                path,
                0,
                duration
            )

        return dispatchGesture(
            GestureDescription.Builder()
                .addStroke(stroke)
                .build(),
            null,
            null
        )
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
