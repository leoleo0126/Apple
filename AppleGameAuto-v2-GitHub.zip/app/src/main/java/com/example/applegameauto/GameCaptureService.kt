package com.example.applegameauto

import android.app.*
import android.content.Intent
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors

class GameCaptureService : Service() {

    companion object {
        @Volatile
        var startIntent: Intent? = null

        private const val CHANNEL_ID = "apple_game_auto"
        private const val NOTIFICATION_ID = 1001

        // 사용자 사진 기준: 1536 × 960
        private const val REF_WIDTH = 1536f
        private const val REF_HEIGHT = 960f

        // 18 × 9
        private const val COLS = 18
        private const val ROWS = 9

        // 사진에서 측정한 각 사과의 중심 좌표
        private const val FIRST_X = 96.0f
        private const val FIRST_Y = 200.0f

        private const val X_GAP = 78.3f
        private const val Y_GAP = 78.3f
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null

    private val executor = Executors.newSingleThreadExecutor()

    private var busy = false
    private var lastAction = 0L

    override fun onCreate() {
        super.onCreate()

        createNotificationChannel()

        val notification =
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("사과게임 자동 플레이")
                .setContentText("게임판을 분석 중입니다.")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .build()

        startForeground(
            NOTIFICATION_ID,
            notification
        )
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        if (projection == null) {
            startCapture()
        }

        return START_NOT_STICKY
    }

    private fun startCapture() {

        val data = startIntent ?: run {
            stopSelf()
            return
        }

        val manager =
            getSystemService(
                MediaProjectionManager::class.java
            )

        projection =
            manager.getMediaProjection(
                Activity.RESULT_OK,
                data
            )

        val metrics = resources.displayMetrics

        val width = metrics.widthPixels
        val height = metrics.heightPixels

        reader =
            ImageReader.newInstance(
                width,
                height,
                PixelFormat.RGBA_8888,
                2
            )

        display =
            projection?.createVirtualDisplay(
                "AppleGameCapture",
                width,
                height,
                metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader!!.surface,
                null,
                Handler(Looper.getMainLooper())
            )

        reader?.setOnImageAvailableListener(
            { r ->

                if (
                    busy ||
                    System.currentTimeMillis() -
                    lastAction < 450
                ) {
                    r.acquireLatestImage()?.close()
                    return@setOnImageAvailableListener
                }

                val image =
                    r.acquireLatestImage()
                        ?: return@setOnImageAvailableListener

                busy = true

                executor.execute {
                    try {
                        analyze(image)
                    } finally {
                        image.close()
                        busy = false
                    }
                }

            },
            Handler(Looper.getMainLooper())
        )
    }

    private fun analyze(image: Image) {

        val bitmap =
            imageToBitmap(image)
                ?: return

        val scaleX =
            bitmap.width / REF_WIDTH

        val scaleY =
            bitmap.height / REF_HEIGHT

        /*
         * 사진에서 각 사과의 실제 중심을 계산한다.
         * 기기 해상도가 달라도 REF 기준으로 확대/축소한다.
         */
        val centers =
            Array(ROWS) { row ->
                Array(COLS) { col ->
                    Pair(
                        (FIRST_X + col * X_GAP) * scaleX,
                        (FIRST_Y + row * Y_GAP) * scaleY
                    )
                }
            }

        /*
         * 각 사과를 개별적으로 OCR한다.
         *
         * 전체 화면을 한 번에 OCR하는 것보다
         * 숫자가 어느 칸에 속하는지 훨씬 안정적으로 판단할 수 있다.
         */
        val tasks =
            mutableListOf<com.google.mlkit.vision.text.TextRecognizer>()

        val recognizer =
            TextRecognition.getClient(
                TextRecognizerOptions.DEFAULT_OPTIONS
            )

        val values =
            Array(ROWS) {
                IntArray(COLS) { 0 }
            }

        val futures =
            mutableListOf<Pair<Int, Int>>()

        /*
         * 현재 화면에 실제 사과가 있는지 먼저 확인한다.
         * 사과 중앙 부근은 주황색이므로 RGB 기준으로 검사한다.
         */
        for (r in 0 until ROWS) {

            for (c in 0 until COLS) {

                val x =
                    centers[r][c].first.toInt()
                        .coerceIn(0, bitmap.width - 1)

                val y =
                    centers[r][c].second.toInt()
                        .coerceIn(0, bitmap.height - 1)

                val pixel =
                    bitmap.getPixel(x, y)

                val red =
                    Color.red(pixel)

                val green =
                    Color.green(pixel)

                val blue =
                    Color.blue(pixel)

                /*
                 * 사진의 사과는
                 * 빨강/주황 계열이다.
                 */
                val looksLikeApple =
                    red > 180 &&
                    red > green * 1.45 &&
                    red > blue * 1.45

                if (looksLikeApple) {
                    futures.add(Pair(r, c))
                }
            }
        }

        if (futures.isEmpty()) {
            bitmap.recycle()
            return
        }

        /*
         * 모든 OCR 작업이 끝난 뒤 한 번만 탐색한다.
         */
        var remaining = futures.size

        for ((r, c) in futures) {

            val cx =
                centers[r][c].first.toInt()

            val cy =
                centers[r][c].second.toInt()

            val halfW =
                (X_GAP * scaleX * 0.40f).toInt()

            val halfH =
                (Y_GAP * scaleY * 0.40f).toInt()

            val left =
                (cx - halfW)
                    .coerceAtLeast(0)

            val top =
                (cy - halfH)
                    .coerceAtLeast(0)

            val right =
                (cx + halfW)
                    .coerceAtMost(bitmap.width)

            val bottom =
                (cy + halfH)
                    .coerceAtMost(bitmap.height)

            val crop =
                Bitmap.createBitmap(
                    bitmap,
                    left,
                    top,
                    right - left,
                    bottom - top
                )

            recognizer.process(
                InputImage.fromBitmap(crop, 0)
            )
                .addOnSuccessListener { result ->

                    val value =
                        result.text
                            .filter { it.isDigit() }
                            .firstOrNull()
                            ?.digitToIntOrNull()

                    if (value != null &&
                        value in 1..9) {

                        values[r][c] = value
                    }
                }
                .addOnCompleteListener {

                    crop.recycle()

                    remaining--

                    if (remaining == 0) {

                        val rect =
                            findRectangle(values)

                        if (rect != null) {
                            performDrag(
                                rect,
                                scaleX,
                                scaleY
                            )
                        }

                        recognizer.close()
                        bitmap.recycle()
                    }
                }
        }
    }

    data class Rect(
        val top: Int,
        val left: Int,
        val bottom: Int,
        val right: Int
    )

    /*
     * 합이 10인 직사각형을 찾는다.
     *
     * 빈 칸은 0으로 취급한다.
     *
     * 가장 작은 영역부터 찾기 때문에
     * 3+7 같은 간단한 조합을 먼저 제거하고,
     * 필요하면 여러 사과를 포함하는 큰 직사각형을 찾는다.
     */
    private fun findRectangle(
        board: Array<IntArray>
    ): Rect? {

        val prefix =
            Array(ROWS + 1) {
                IntArray(COLS + 1)
            }

        for (r in 0 until ROWS) {

            for (c in 0 until COLS) {

                prefix[r + 1][c + 1] =
                    board[r][c] +
                    prefix[r][c + 1] +
                    prefix[r + 1][c] -
                    prefix[r][c]
            }
        }

        var best: Rect? = null
        var bestArea = Int.MAX_VALUE

        for (top in 0 until ROWS) {

            for (bottom in top until ROWS) {

                for (left in 0 until COLS) {

                    for (right in left until COLS) {

                        val sum =
                            prefix[bottom + 1][right + 1] -
                            prefix[top][right + 1] -
                            prefix[bottom + 1][left] +
                            prefix[top][left]

                        if (sum != 10) continue

                        val area =
                            (bottom - top + 1) *
                            (right - left + 1)

                        if (area < bestArea) {

                            bestArea = area

                            best =
                                Rect(
                                    top,
                                    left,
                                    bottom,
                                    right
                                )
                        }
                    }
                }
            }
        }

        return best
    }

    private fun performDrag(
        rect: Rect,
        scaleX: Float,
        scaleY: Float
    ) {

        val service =
            AppleAccessibilityService.instance
                ?: return

        val startX =
            (FIRST_X +
                rect.left * X_GAP) *
                scaleX

        val startY =
            (FIRST_Y +
                rect.top * Y_GAP) *
                scaleY

        val endX =
            (FIRST_X +
                rect.right * X_GAP) *
                scaleX

        val endY =
            (FIRST_Y +
                rect.bottom * Y_GAP) *
                scaleY

        /*
         * 사과 중심에서 시작해서
         * 반대쪽 사과 중심까지 드래그한다.
         */
        service.drag(
            startX,
            startY,
            endX,
            endY,
            220L
        )

        lastAction =
            System.currentTimeMillis()
    }

    private fun imageToBitmap(
        image: Image
    ): Bitmap? {

        val plane =
            image.planes[0]

        val buffer =
            plane.buffer

        val pixelStride =
            plane.pixelStride

        val rowStride =
            plane.rowStride

        val rowPadding =
            rowStride -
            pixelStride * image.width

        val bitmap =
            Bitmap.createBitmap(
                image.width +
                    rowPadding / pixelStride,
                image.height,
                Bitmap.Config.ARGB_8888
            )

        buffer.rewind()
        bitmap.copyPixelsFromBuffer(buffer)

        if (bitmap.width == image.width) {
            return bitmap
        }

        return Bitmap.createBitmap(
            bitmap,
            0,
            0,
            image.width,
            image.height
        ).also {
            bitmap.recycle()
        }
    }

    private fun createNotificationChannel() {

        if (Build.VERSION.SDK_INT >= 26) {

            val manager =
                getSystemService(
                    NotificationManager::class.java
                )

            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "사과게임 자동 플레이",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }
    }

    override fun onDestroy() {

        reader?.close()
        display?.release()
        projection?.stop()

        executor.shutdownNow()

        super.onDestroy()
    }

    override fun onBind(
        intent: Intent?
    ): android.os.IBinder? = null
}
