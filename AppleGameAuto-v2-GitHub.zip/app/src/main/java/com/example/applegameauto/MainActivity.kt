package com.example.applegameauto

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView

class MainActivity : Activity() {

    companion object {
        private const val REQ_CAPTURE = 5001
    }

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)

        findViewById<Button>(R.id.accessibilityButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.captureButton).setOnClickListener {
            val manager = getSystemService(MediaProjectionManager::class.java)
            startActivityForResult(
                manager.createScreenCaptureIntent(),
                REQ_CAPTURE
            )
        }

        findViewById<Button>(R.id.startButton).setOnClickListener {
            if (AppleAccessibilityService.instance == null) {
                status.text = "자동 터치 권한을 먼저 허용하세요."
                return@setOnClickListener
            }

            if (GameCaptureService.startIntent == null) {
                status.text = "화면 캡처 권한을 먼저 허용하세요."
                return@setOnClickListener
            }

            val intent = Intent(this, GameCaptureService::class.java)

            if (android.os.Build.VERSION.SDK_INT >= 26) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }

            status.text = "자동 플레이 실행 중..."
        }

        findViewById<Button>(R.id.stopButton).setOnClickListener {
            stopService(Intent(this, GameCaptureService::class.java))
            status.text = "자동 플레이 중지"
        }
    }

    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        if (
            requestCode == REQ_CAPTURE &&
            resultCode == RESULT_OK &&
            data != null
        ) {
            GameCaptureService.startIntent = data
            status.text = "화면 캡처 권한 허용 완료"
        }
    }
}
